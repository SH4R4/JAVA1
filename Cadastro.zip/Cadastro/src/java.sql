create database projetojava;
use projetojava;

create table usuario(
id bigint (10) auto_increment,
sexo enum ('Feminino', 'Masculino'),
nome varchar (255),
nascimento date,
cpf varchar (255),
rg varchar (229),
email varchar (255),
telefone varchar(255),
habilitado enum ('sim', 'não'),

primary key (id)
);